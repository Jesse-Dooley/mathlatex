<?php
/**
 *
 */
$requiredlibs = array(
	'ImageMagick',
	'ghostscript',
	'texlive',
	'texlive-collection-basic',
	'texlive-collection-latex',
	'texlive-collection-latexrecommended',
	'texlive-collection-pstricks',

);

$seachlibs = array(
	'ImageMagick',
	'ghostscript',
	'poppler-data',
	'popt',
	'texlive',
	);
?>